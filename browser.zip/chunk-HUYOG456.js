import{g as a}from"./chunk-P4F3WYZT.js";export{a as BrowserPerformanceMeasurement};
